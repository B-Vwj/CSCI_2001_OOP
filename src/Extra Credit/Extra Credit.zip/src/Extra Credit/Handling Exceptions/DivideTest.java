public class DivideTest {

    public static void main(String args[]) {
        Divide divide = new Divide();
        divide.divideWrapper(1, 0);
    }

}
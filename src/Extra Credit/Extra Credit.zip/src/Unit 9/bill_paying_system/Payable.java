public interface Payable {
    public double getPayment();
}